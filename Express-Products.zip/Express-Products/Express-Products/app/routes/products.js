var express = require('express');
var router = express.Router();
var fs = require('fs');

fs.readFile('products.json', 'utf-8', function read(err, data) {

    var products = JSON.parse(data);

    function saveJSON() {
        var newJSON = {};
        newJSON.products = products;

        fs.writeFile('products.json', JSON.stringify(newJSON), (err) => {
            if (err) throw err;
        });
    }

    /* GET all products */
    router.get('/', function (req, res, next) {
        res.json(products);
    });

    /* GET one product */
    router.get('/:id', function (req, res, next) {
        let foundProducts = products.filter(function (p) {
            return p.id == req.params.id;
        });

        if (foundProducts.length == 1) {
            res.json(foundProducts[0]);
        }
        else {
            res.json("{'Not found'}");
        }
    });

    router.delete('/delete/:id([A-Z]{3}-[0-9]{2})', (req, res, next) => {
        let newProducts = products.filter(product => product.id != req.params.id);
        fs.writeFile('products.json', JSON.stringify(newProducts), () => {
            res.send(`Product met id ${req.params.id} is verwijderd`)
        });
    })

    router.put('/:id([A-Z]{3}-[0-9]{2})', (req, res, next) => {
        let newProduct = req.body;
        let newProducts = products;
        newProduct["id"] = req.params.id;
        newProducts.push(newProduct);
        fs.writeFile('products.json', JSON.stringify(newProducts), () => {
            res.send(`Product met id ${req.params.id} is toegevoegd`);
        });
    })
});

module.exports = router;